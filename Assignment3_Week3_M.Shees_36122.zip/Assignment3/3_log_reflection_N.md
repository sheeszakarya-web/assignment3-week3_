# Log and reflection

**Name:** M. Shees Zakarya  **ERP ID:** 36122

## 2. ASK: Interpretation Auditor (transcript excerpt)

## 3. CHECK: audit table

Colours: green = I can recompute it, amber = an explanation, red = a causal claim or about data not shown.
Sentence numbers refer to the referee's note in `1_attempt.md`.

| # | Claim | Colour | How I checked | Accepted / rejected |
|---|---|---|---|---|
| 1 | Sweetener D rose 149.0 to 178.5 (City 1) and 155.0 to 184.5 (City 2), about 19 to 20% | Green | Rows 2026-01-01 and 2026-03-19 in `teaching_prices_clean.csv`; notebook gives +19.80% and +19.03% | Accepted |
| 2 | Oil B about 15%, Staple A about 13%, Pulse C about 2 to 4% | Green | Notebook per-city table: 15.44/15.13, 13.37/12.62, 3.75/2.40 | Accepted |
| 3 | Mean and median differ by at most 1.24 PKR/kg after cleaning | Green | `mean_minus_median` column; largest absolute value is Staple A, -1.24 | Accepted |
| 4 | With the 9999 entry, Sweetener D mean 576.81, median 167.75 | Green | Recomputed in the notebook from the `price_raw` column of the cleaned file (24 values, including 9999) | Accepted |
| 5 | 9999 is probably a placeholder code, not a price | Amber | Cannot be recomputed. Supported by the other 23 prices lying in 149.0 to 184.5, but the cause is an assumption | Accepted as an explanation, labelled E |
| 6 | One neighbour may be quoting a contaminated average | Amber | Plausible story about the argument; nothing in the data shows who said what | Accepted as an explanation, labelled E |
| 7 | An average over the whole period does not show whether the price rose | Green | Every item-city series ends higher than it starts (all eight first-to-last changes are positive), so early and late weeks differ; first-to-last change is computed separately | Accepted |
| 8 | Median for typical level, percentage change for "did it go up" | Amber | A recommendation, not a computed fact | Accepted, labelled E |
| - | "The staple's price really went up" (real-world claim, from the brief's framing) | Red | The file is labelled illustrative teaching data, not actual observations, so it cannot support a claim about real prices | Rejected; the note only says what the teaching file shows |
| - | "Pulse C rose about 5%" (pooled weekly mean, 200.0 to 210.5) | Green number, wrong method | Pulse C City 2 is blank on 1 Jan, so the first pooled week contains only City 1 while the last contains both cities | Rejected; replaced by per-city 3.75% and 2.40% |


## 5. REFLECT: where did the first draft say more than the data allowed?

1. **A first, pooled item-level change for Pulse C (about 5%) looked reasonable but was wrong.** The 1 January price for City 2 is blank, so comparing the first and last weeks mixed one city with two. Computing within each city fixed it.
2. **Calling 9999 "a placeholder" is a guess.** I can show it is far outside the series, but not why it is there. It stays labelled E, not O.
3. **The referee's ruling in sentence 8 is a judgement.** It depends on which question the neighbours are asking, so I labelled it E.
4. **The file is illustrative.** The brief talks about a real staple going up, but this data cannot support any claim about real prices, so the note stays inside "in the teaching file".
5. **No causal claim is made.** The data show that prices rose, not what made them rise.
