# AI use log: Assignment 3 (Week 3)

**Name:** M. Shees Zakarya  **ERP ID:** 36122

| What | Tool | What I did with the output | How I checked it |
|---|---|---|---|
| Rebuilt the cleaned CSV from my own Week 2 cleaning code | Claude | Used as `teaching_prices_clean.csv` | Row count (96), valid prices (93) and mean (203.61) match my notebook |
| Computed mean, median, first-to-last change, and the with/without comparison | Claude | Written as `2_work.ipynb`, starting from the cleaned CSV | Re-ran the cells; asserts in the last cell pass |
| Drafted the referee's note, audit table and reflection | Claude | `1_attempt.md`, `3_log_reflection.md` | Recomputed every number; reflection edited by me |

> Edit this log so it matches what you actually did and which parts you rewrote yourself.
